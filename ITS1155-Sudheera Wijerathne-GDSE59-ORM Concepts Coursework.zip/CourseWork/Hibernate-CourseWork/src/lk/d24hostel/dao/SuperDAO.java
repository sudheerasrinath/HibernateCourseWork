package lk.d24hostel.dao;

public interface SuperDAO {
}
