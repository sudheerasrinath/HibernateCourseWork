package lk.d24hostel.dao;

public class DAOFactory {
}
