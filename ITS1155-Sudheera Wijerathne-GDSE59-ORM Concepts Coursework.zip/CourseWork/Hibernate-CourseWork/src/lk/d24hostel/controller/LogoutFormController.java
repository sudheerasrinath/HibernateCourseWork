package lk.d24hostel.controller;

public class LogoutFormController {
}
