package lk.d24hostel.controller;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;


public class LoginFormController {
    public Label lblUserName;
    public Label lblPassword;
    public JFXTextField txtUserName;
    public JFXPasswordField pwdPassword;
    public AnchorPane MainAnchorPane;


    public void SignUpOnAction(ActionEvent actionEvent) {
    }

    public void ForgetOnAction(ActionEvent actionEvent) {
    }

    public void btnLogInOnAction(ActionEvent actionEvent) throws IOException {


    }


    }

