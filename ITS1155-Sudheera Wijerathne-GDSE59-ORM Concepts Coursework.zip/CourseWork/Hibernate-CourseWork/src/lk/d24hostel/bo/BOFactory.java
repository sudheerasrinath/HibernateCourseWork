package lk.d24hostel.bo;

public class BOFactory {
}
