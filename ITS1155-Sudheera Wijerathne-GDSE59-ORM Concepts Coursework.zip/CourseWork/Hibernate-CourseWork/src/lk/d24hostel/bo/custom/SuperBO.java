package lk.d24hostel.bo.custom;

public interface SuperBO {
}
