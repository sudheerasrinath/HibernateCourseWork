package lk.d24hostel.bo.custom.impl;

import lk.d24hostel.bo.custom.RoomBO;
import lk.d24hostel.dao.custom.RoomDAO;
import lk.d24hostel.dao.custom.impl.RoomDAOImpl;
import lk.d24hostel.dto.RoomDTO;
import lk.d24hostel.entity.Room;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ROOMBOImpl implements RoomBO {

    RoomDAO roomDAO = new RoomDAOImpl();

    @Override
    public ArrayList<RoomDTO> getAllRoom() throws IOException {
        ArrayList<Room> all = roomDAO.getAll();

        ArrayList<RoomDTO> allRoom = new ArrayList<>();

        for (Room room : all) {
            allRoom.add(new RoomDTO(room.getRoomTypeId(),room.getType(),room.getKeyMoney(),room.getQty()));
        }
        return allRoom;
    }

    @Override
    public boolean saveRoom(RoomDTO dto) throws IOException {
        return roomDAO.save(new Room(
                dto.getRoomTypeId(),
                dto.getType(),
                dto.getKeyMoney(),
                dto.getQty()
        ));
    }

    @Override
    public boolean updateRoom(RoomDTO dto) throws IOException {
        return roomDAO.update(new Room(
                dto.getRoomTypeId(),
                dto.getType(),
                dto.getKeyMoney(),
                dto.getQty()
        ));
    }

    @Override
    public boolean deleteRoom(String id) throws IOException {
        return roomDAO.delete(id);
    }

    @Override
    public String generateRoomId() {
        return null;
    }

    @Override
    public List<Room> getRoomDataFromType(String type) throws IOException {
        return roomDAO.getRoomDataFromType(type);
    }

    @Override
    public Room getRoom(String id) throws IOException {
        return roomDAO.getRoom(id);
    }
}
